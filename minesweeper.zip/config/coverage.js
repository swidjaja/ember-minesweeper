module.exports = {
  coverageEnvVar: 'COVERAGE',
  reporters: ['lcov', 'html', 'text-summary'],
  useBabelInstrumenter: true
};
