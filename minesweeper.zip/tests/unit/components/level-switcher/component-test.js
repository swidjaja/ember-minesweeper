// import { expect } from 'chai';
// import { describe, it } from 'mocha';
// import { setupComponentTest } from 'ember-mocha';
// import sinon from 'sinon';


// describe('Unit | Component | Level Switcher', () => {
//   setupComponentTest('level-switcher', {
//     unit: true
//   });

//   it('sends action with correct param when it does selectLevel', function () {
//     const component = this.subject();
//     const sendActionSpy = sinon.spy();
//     component.actions.sendAction = sendActionSpy;

//     this.render();
//     component.actions.selectLevel();

//     expect(sendActionSpy.calledOnce).to.equal(true);
//   });
// });
